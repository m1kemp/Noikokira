create
    definer = rootUser@localhost procedure addProduct(IN productName varchar(50), IN categoryName varchar(50))
BEGIN
    SELECT COUNT(*) INTO @catNum FROM item_category where category_name=categoryName;
    IF @catNum = 0 THEN
        INSERT INTO item_category (category_name) VALUES(categoryName);
    END IF;

    SELECT category_id INTO @catID FROM item_category WHERE category_name=categoryName;

    INSERT INTO item (category_id, item_name) VALUES(@catID, productName);

END;

