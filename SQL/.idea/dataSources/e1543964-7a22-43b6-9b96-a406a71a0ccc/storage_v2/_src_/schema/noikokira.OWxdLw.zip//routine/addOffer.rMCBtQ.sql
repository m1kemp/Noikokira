create
    definer = rootUser@localhost procedure addOffer()
BEGIN

END;

