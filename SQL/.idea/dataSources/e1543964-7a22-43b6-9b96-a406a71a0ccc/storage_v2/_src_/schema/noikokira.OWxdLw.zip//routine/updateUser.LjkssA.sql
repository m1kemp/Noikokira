create
    definer = rootUser@localhost procedure updateUser(IN usrID smallint unsigned, IN newEmail varchar(45),
                                                      IN newUsername varchar(45), IN newPassword varchar(64))
BEGIN
    SELECT COUNT(*) INTO @userNum FROM user WHERE email=newEmail AND user_id!=usrID;
    IF @userNum = 0 THEN
        UPDATE user SET user.username=newUsername, user.password=newPassword, user.email=newEmail WHERE user_id=usrID;
    ELSE
        SELECT -1;
    end if;
END;

