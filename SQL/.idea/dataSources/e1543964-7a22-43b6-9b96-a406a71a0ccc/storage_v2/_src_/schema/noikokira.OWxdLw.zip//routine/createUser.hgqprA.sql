create
    definer = rootUser@localhost procedure createUser(IN newEmail varchar(45), IN newUsername varchar(45),
                                                      IN newPassword varchar(64))
BEGIN
    SELECT COUNT(*) INTO @userNum FROM user WHERE email=newEmail;
    IF @userNum = 0 THEN
        INSERT INTO user (username, email, password, points, tokens) VALUES(newUsername, newEmail, newPassword, 0, 0);
    ELSE
        SELECT -1;
    end if;
END;

