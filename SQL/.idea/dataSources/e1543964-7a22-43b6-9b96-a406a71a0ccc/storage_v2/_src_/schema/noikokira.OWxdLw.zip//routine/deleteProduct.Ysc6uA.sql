create
    definer = rootUser@localhost procedure deleteProduct(IN productName varchar(50))
BEGIN
    DELETE FROM item WHERE item_name=productName;
END;

