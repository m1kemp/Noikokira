var username="123";
const userField=document.getElementById("username");
userField.setAttribute("value",username);